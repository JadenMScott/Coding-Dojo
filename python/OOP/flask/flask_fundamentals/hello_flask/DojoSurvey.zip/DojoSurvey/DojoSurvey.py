from flask import Flask,render_template
app=Flask(__name__)
app.route("/")
def reg():
    return render_template("index.html",action)

app.route("/result")
def reg():
    return render_template("index.html",action)


if __name__=="__main__":
    app.run(debug=True)