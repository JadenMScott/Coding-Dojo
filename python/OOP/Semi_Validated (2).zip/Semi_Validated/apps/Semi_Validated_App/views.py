from django.shortcuts import render,redirect
from .models import Shows


def add(request):
    if request.method == "POST":
        shows=request.POST['title']
        release_date=request.POST['release_date']
        description=request.POST['Description']
        network=request.POST['network']
        Shows.objects.create(title=shows, release_date=release_date, description=description,network=network)
    return render(request, 'Semi_Validated_App/add.html')

def display(request):
    context={
        "all_shows" : Shows.objects.all()
    }
    return render(request,'Semi_Validated_App/display.html',context)
    
def edit(request,val):
    context={
        "edit_show":Shows.objects.update()
    }
    return render(request, 'Semi_Validated_App/edit.html',context)

def display_one(request,val):
    context={
        "show_info":Shows.objects.get(id=val)
    }
    return render(request, 'Semi_Validated_App/display_one.html',context)

def destroy(request,val):
    c=Shows.objects.get()