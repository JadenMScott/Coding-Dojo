from django.apps import AppConfig


class SemiValidatedAppConfig(AppConfig):
    name = 'Semi_Validated_App'
