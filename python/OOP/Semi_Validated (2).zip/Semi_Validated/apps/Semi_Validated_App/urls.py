from django.conf.urls import url
from . import views

urlpatterns={
    url(r'^add$',views.add),
    url(r'^display',views.display),
    url(r'^display/{{s.id}}$',views.display_one),
    url(r'^edit/{{s.id}}$',views.edit),
    url(r'^destroy/{{s.id}}$',views.destroy),
}