﻿using System;
using System.Collections.Generic;
namespace BoxingUnboxing
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            List <object> obj=new List<object>();
            obj.Add(7);
            obj.Add(28);
            obj.Add(-1);
            obj.Add(true);
            obj.Add("chair");

            for(int i =0;i<obj.Count;i++){
                Console.WriteLine(obj[i]);
            
                foreach(int num in obj){
                    int count =0;
                    if(obj[i].Type=='int'){
                        count += obj[i];
                    }
                }
                Console.WriteLine(count);
            }
        }
    }
}
